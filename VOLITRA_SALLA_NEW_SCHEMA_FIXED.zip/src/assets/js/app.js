document.addEventListener('DOMContentLoaded',()=>{document.documentElement.classList.add('volitra-ready');});
