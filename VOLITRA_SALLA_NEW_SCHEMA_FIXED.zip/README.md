# VOLITRA Twilight Theme

A blue/black electronics storefront starter for Salla Twilight.

## Important
This package is a **Twilight starter/custom theme**, not a PDF or static website. Salla Twilight uses Twig and a `twilight.json` configuration file.

## Upload
For a GitHub repository, keep the folder structure intact and upload the contents of this ZIP to the repository root.

## Main customization
- `src/views/components/home/volitra-electronics-slider.twig` — animated electronics strip.
- `src/assets/styles/app.scss` — Volitra visual design.
- `twilight.json` — theme settings and component registration.

The product strip accepts images through the component collection in Salla Partners Portal.
